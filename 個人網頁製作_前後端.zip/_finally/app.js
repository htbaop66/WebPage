var http = require("http");
var path = require("path");
var express = require("express");
var logger = require("morgan");
var bodyParser = require("body-parser");

var app = express();

app.set("views", path.resolve(__dirname, "views"));
app.use(express.static(path.resolve(__dirname, "public")));
app.set("view engine", "ejs");


var entries = [];
app.locals.entries = entries;

app.use(logger("dev"));

app.use(bodyParser.urlencoded({ extended: false }));


app.get("/", function(request, response) {
  response.render("home");
});

app.get("/index", function(request, response) {
  response.render("index");
});

app.get("/dogPicture", function(request, response) {
  response.render("dogPicture");
});
app.get("/dogPicture2", function(request, response) {
  response.render("dogPicture2");
});
app.get("/dogPicture3", function(request, response) {
  response.render("dogPicture3");
});

app.get("/aboutMe", function(request, response) {
  response.render("aboutMe");
});

app.get("/zip", function(request, response) {
  response.render("zip");
});

app.get("/new-entry", function(request, response) {
  response.render("new-entry");
});


app.post("/new-entry", function(request, response) {
  console.log(request.body.name+"  "+request.body.yn)
  if (!request.body.name || !request.body.yn || !request.body.score || !request.body.yourclass) {
    response.status(400)
      .send("喔喔..沒填完整喔。回去檢查，看看哪欄沒填到。");
    return; 
  }

  entries.push({
    name: request.body.name,
    yn: request.body.yn,
    score: request.body.score,
    //phone: request.body.phone,
    yourclass: request.body.yourclass,
    published: new Date()
  });

  response.redirect("/index");
});


app.use(function(request, response) {
  response.status(404).render("404");
});

http.createServer(app).listen(3000, function() {
  console.log("Guestbook app started on port 3000.");
});